<?php defined('BASEPATH') OR exit('No direct script access allowed');

class RuleOperators extends Admin_Controller
{
	switch (variable) {
		case '>':
			# code...
			break;
		case '>':
			# code...
			break;
		case '=':
			# code...
			break;
		
		default:
			# code...
			break;
	}
}