<?php  if(!defined('BASEPATH')) exit('No direct script access allowed');
class Threshold2_model extends MY_Model
{

	public function __construct()
	{
       
        //$this->load->model('Googleanalyticsdata_model', 'gmodel');
        $this->load->library('NarrationEngine');
		parent::__construct();

	}

   
    public function getnarration($currentdata,$historicaldata,$r)
    {
       
            $a = array();
            $c = array();
            $b = array();
            $val1 = array();
            $val2 = array();
            $result = array();

            $indexes_current = array('sessions','users','desktop_users','mobile_users','pageviews','unique','swe','exitrate',
            'duration','bouncerate','pathloss','ved','pcc','newpercent','spu','entrytoexit',
            'pagedepth','traffic','conversions','rvr');
           
          foreach($indexes_current as $index)
          {
            $val1[$index] = $currentdata[$index]['upper_limit'];
            $val2[$index] = $currentdata[$index]['lower_limit'];
          }
          
          foreach($indexes_current as $index2)
          {
            $a[$index2] = $historicaldata[$index2]['upper_limit'];
            $c[$index2] = $historicaldata[$index2]['lower_limit'];
            $b[$index2] =  ($a[$index2] +  $c[$index2])/2;
          }
         /* echo '<pre>';
          print_r($b);
          echo '</pre>';*/
         $interpretation;
        foreach($indexes_current as $index)
        {
            if($val1[$index] > $a[$index] || $val1[$index] <= $a[$index] && $val1[$index] > $b[$index] && $r > 0)
            {
                if($val2[$index] <= $a[$index] && $val2[$index] >= $c[$index])
                {
                   $interpretation = 'positive';
                    /*if($r > 0)
                    {
                        $interpretation = 'positive';
                    }
                    elseif($r < 0)
                    {
                        $interpretation = 'positive';
                    }
                    else
                    {
                        $interpretation = 'positive';
                    }*/
               }
            }                   
            elseif($val1[$index] < $b[$index] && $val1[$index] >= $c[$index] && $r < 0)
            {
                if($val2[$index] < $b[$index] && [$index] >= $c[$index])
                {
        
                    $interpretation = 'negative';
                   /* if($r > 0)
                    {

                        $interpretation = 'negative';
                    }
                    elseif($r < 0)
                    {
                        $interpretation = 'negative';
                    } 
                    else
                    {
                        $interpretation = 'negative';
                    }*/
                }
            }
            elseif($val1[$index] == $b[$index] && $r == 0 )
            {
               if($val2[$index] == $b[$index] && $val2[$index] >= $c[$index])
               {
                
                    $interpretation = 'equal';
                    /*if($r > 0)
                    {
                        $interpretation = 'equal';
                    }
                    elseif($r < 0)
                    {
                        $interpretation = 'equal';
                    }
                    else
                    {
                        $interpretation = 'equal';
                    }*/
                }
            }
            else
            {
                $interpretation = 'outlier';
            }
          
              $result[$index] = $interpretation;
        }
          
        return $result;
    }



    public function fetch($interpretation,$metric)
    {
        
        $result = array();
        $output = array();
        
       foreach($interpretation as $key=>$value)
        {

        switch($value)
        {
            case 'positive':
          
            $output = $this->db->select('greaterthan')
                    ->from('metrics')
                    ->where('name',$key)
                    ->get()->result_array();
            break;
            case 'negative':
            
            $output = $this->db->select('lessthan')
                            ->from('metrics')
                            ->where('name',$key)
                            ->get()->result_array();
            break;
            case 'equal':
           
            $output = $this->db->select('equalto')
                            ->from('metrics')
                            ->where('name',$key)
                            ->get()->result_array();
            break;
            case 'outlier':
            $output = "values are not appropriate.";
            break;
            
            }
            array_push($result,$output);
         }
    return $result;
    
    }


   
        
}