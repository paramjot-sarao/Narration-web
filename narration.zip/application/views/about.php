<!DOCTYPE html PUBLIC "-//w3c//OTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/OTD/xhtml1-strict.dtd">
<html>
<head>
<title></title>
<meta http-eqiv="Content-Type" content="text/html; charset=UTF-8">
</head>

<body>
<div id="container">
<p> this is the about page.My view has been loaded.</p>

</div>

</body>
</html>
