<?php

echo $output->output;
echo "<br>";
echo "In the above table, the columns named Key1,Key2,....so on represents the scale values and";

echo "<br>";
echo "columns named Value1,Value2,....so on represents the interpretation of the values according to the different Likert scales.";
 ?>