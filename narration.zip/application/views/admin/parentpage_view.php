<?php defined('BASEPATH') OR exit('No direct script access allowed');?>


<div class="row">
	<div class="col-lg-12">
		<h2>Welcome to Sample Page</h2>
	</div>
    <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
