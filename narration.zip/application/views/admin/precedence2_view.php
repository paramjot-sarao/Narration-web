<table class = "table table-striped">
<thead>
	<tr>
	<th>Final Questions:</th>
	</tr>
</thead>
<tbody>
	<?php 
		foreach($temp2 as $val) { ?>
		<tr>
			<td><?php// echo "Question Id"." No.".$val;?></td>			
		</tr>
		<?php 
		
		} ?>
	
</tbody>
</table>
